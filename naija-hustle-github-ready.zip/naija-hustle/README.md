# 🇳🇬 Naija Hustle

A self-contained Nigerian business/tycoon game built with React + Vite.

## Independence

The core game does **not** require:
- AppDeploy
- ChatGPT
- an AI API
- a database
- a paid backend
- an internet connection after the app is loaded

Game state is saved locally in the browser with `localStorage`.

Optional online features can be added later without changing the core economy.

## Included features

- Starting cash and Nigerian economy
- Multiple businesses and upgrades
- Multiple bank accounts, each with its own balance/UI
- Transfers between bank accounts
- Property portfolio with rent and appreciation
- Vehicle garage with running costs and resale values
- Daily income simulation
- Random Nigerian-style business events
- Missions and XP
- Levels and reputation
- Net-worth tracking
- Transaction history
- Offline autosave
- Reset/save export/import
- Responsive mobile-first interface
- Built-in SVG visual assets; no external image host required
- GitHub Actions deployment workflow

## Run locally

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

## GitHub Pages

The included `.github/workflows/deploy.yml` builds and publishes the Vite app.

For a repository project page, the workflow works with the relative Vite base configured in `vite.config.js`.

## Architecture

`src/game/engine.js` contains deterministic game rules. `src/data/` contains all content. `src/App.jsx` is the UI shell.

Nothing calls ChatGPT at runtime.
